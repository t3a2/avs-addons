# -*- coding: utf-8 -*-
from LIBRARY import *



DIALOG_NOTIFICATION('TEST','TEST')

#url = 'c:\\asdf.mp3'
#url = 'C:\\TEMP\\temp\\asdf.mp3'
#url = 'C:\\TEMP\\temp\\aa bb\\asdf.mp3'


url = 'C:\\TEMP\\temp\\aa bb\\فحص.mp3'

#url = url.decode('utf8')



xbmc.Player().play(url)


