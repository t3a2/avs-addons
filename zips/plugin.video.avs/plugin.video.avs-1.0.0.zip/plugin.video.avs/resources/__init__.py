# -*- coding: utf-8 -*-
from LIBRARY import *

DEBUG = False
#DEBUG = True

if DEBUG:
	import sys  # pydevd module need to be copied in Kodi\system\python\Lib\pysrc
	sys.path.append('C:\Program Files\Kodi\system\Python\Lib\pysrc')
	try:
		import pysrc.pydevd as pydevd
		pydevd.settrace('localhost', stdoutToServer=True, stderrToServer=True)
	except ImportError:
		try:
			import pydevd  # with the addon script.module.pydevd, only use `import pydevd`
			pydevd.settrace('localhost', stdoutToServer=True, stderrToServer=True)
		except ImportError:
			sys.stderr.write("Error: " + "You must add org.python.pydev.debug.pysrc to your PYTHONPATH.")

LOG_THIS('NOTICE','================================================================================================================================================================')

#a = READ_FROM_SQL3('MISC','USERAGENT123')
#DIALOG_OK(str(a),str(a))

DIALOG_BUSY('start')

try: MAIN()
except Exception as error: HANDLE_EXIT_ERRORS(error)

DIALOG_BUSY('stop')
